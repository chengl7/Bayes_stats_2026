# Day 2 make-up submission

You may miss **at most one** of the six course days (see [../grading.md](../grading.md)). If you have to miss Day 2:

1. **Inform the lecturer in advance**, before the day starts. In case of sudden illness, do so as early as possible.
2. **Submit individually**, normally **within one week** of the missed day:
   - **The in-class exercises:** your own solutions to the core exercises of [`day-2-exercises-morning.ipynb`](day-2-exercises-morning.ipynb) (A) and [`day-2-exercises-afternoon.ipynb`](day-2-exercises-afternoon.ipynb) (B), with outputs and written answers.
   - **The extra exercises:** Parts **A and B** of [`extra/day-2-extra-exercises.ipynb`](extra/day-2-extra-exercises.ipynb), with outputs and written answers. The C-problems are optional.

No Stan is needed.

**Grading.** The lecturer grades your make-up submission on the same 0–4 scale used for in-class activity, judging effort and your own reasoning, and that score counts as your in-class score for Day 2. Copying the released class solutions earns nothing; the extra exercises use new problems and data for this reason. Without advance notice, or without a submission, the attendance requirement is not met (see [../grading.md](../grading.md)).

**Before you start,** go through the Day 2 slides ([morning](day-2-slides-morning.pdf) and [afternoon](day-2-slides-afternoon.pdf)) and the [demos](demos/README.md). The extra exercises contain hints. Their worked solutions are released only after the make-up deadline.

**Your own work.** Discussing ideas is fine. The code and explanations must be your own. You may use AI assistants without declaring it, but you should be able to explain every answer.

Students who attended are welcome to use the extra exercises for practice; nothing is submitted in that case.
